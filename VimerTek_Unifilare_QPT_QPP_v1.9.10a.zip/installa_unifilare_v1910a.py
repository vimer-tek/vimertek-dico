#!/usr/bin/env python3
"""Installatore mirato per la versione Vimer Tek Di.Co. v1.9.10.
Modifica soltanto app.js e conserva un backup prima di scrivere.
"""
from pathlib import Path
from datetime import datetime
import subprocess
import sys

ROOT = Path.cwd()
APP = ROOT / 'app.js'
PATCH = Path(__file__).resolve().parent / 'unifilare_v1910a.js'
MARKER = 'VT_UNIFILARE_GERARCHICO_V1910A'
CSS_OLD = '.vt-attachment-page img{max-width:100%;width:auto;height:auto;max-height:222mm;object-fit:contain;display:block;margin:0 auto}'
CSS_NEW = '.vt-unifilar-sheet{break-before:page!important;page-break-before:always;break-inside:avoid!important;} .vt-unifilar-sheet h2{margin:1mm 0 2mm!important;font-size:13pt;} .vt-unifilar-sheet .notice{margin:1mm 0 2mm;font-size:8pt;padding:1mm 2mm;} .vt-unifilar-sheet-svg{width:100%;max-width:180mm;page-break-inside:avoid;} .vt-unifilar-sheet-svg svg{display:block;width:100%;height:auto;} '
PRINT_OLD = "if(id==='unifilar')return `<section class='print-section'>"
PRINT_NEXT = "if(id==='ministerial')"

def one(s, token, label):
    n = s.count(token)
    if n != 1:
        raise ValueError(f"STOP: trovato {n} volte {label}; atteso 1. Nessuna modifica eseguita.")

try:
    if not APP.is_file():
        raise ValueError('STOP: app.js non trovato. Apri il terminale nella cartella principale del progetto.')
    if not PATCH.is_file():
        raise ValueError('STOP: manca unifilare_v1910a.js. Estrai tutti i file dello ZIP.')
    s = APP.read_text(encoding='utf-8')
    if MARKER in s:
        print('OK: aggiornamento unifilare v1.9.10a gia presente. Nessuna modifica eseguita.')
        sys.exit(0)
    a_tag, b_tag = 'function unifilarSVG(){', 'function refreshSchema(){'
    for token,label in [(a_tag,'funzione unifilarSVG'),(b_tag,'funzione refreshSchema'),(PRINT_OLD,'blocco stampa unifilare'),(PRINT_NEXT,'marcatore stampa ministeriale'),(CSS_OLD,'stile allegati')]:
        one(s,token,label)
    a = s.index(a_tag)
    b = s.index(b_tag, a)
    old = s[a:b]
    if 'schemaDevice' not in old or 'VT_UNIFILARE_FIRMA_DT_V197A' not in old:
        raise ValueError('STOP: versione del generatore diversa da quella verificata. Nessuna modifica eseguita.')
    extra = PATCH.read_text(encoding='utf-8')
    if MARKER not in extra or 'function unifilarPrintPages()' not in extra:
        raise ValueError('STOP: file di aggiornamento incompleto.')
    legacy = old.replace(a_tag,'function unifilarSVGLegacy(){',1)
    s = s[:a] + legacy + extra + s[b:]
    p0 = s.index(PRINT_OLD)
    p1 = s.index(PRINT_NEXT,p0)
    s = s[:p0] + "if(id==='unifilar')return unifilarPrintPages();\n" + s[p1:]
    s = s.replace(CSS_OLD, CSS_OLD+'\n'+CSS_NEW, 1)
    backup = ROOT / f"app.js.backup_unifilare_v1910a_{datetime.now():%Y%m%d_%H%M%S}"
    backup.write_text(APP.read_text(encoding='utf-8'),encoding='utf-8')
    APP.write_text(s,encoding='utf-8')
    check = subprocess.run(['node','--check',str(APP)],capture_output=True,text=True)
    if check.returncode != 0:
        APP.write_text(backup.read_text(encoding='utf-8'),encoding='utf-8')
        raise ValueError('STOP: verifica JavaScript non superata. Ripristinato app.js originale.\n'+check.stderr)
    print('OK - Installazione riuscita: schema QPT/QPP gerarchico v1.9.10a')
    print('OK - Backup creato:',backup.name)
    print('OK - app.js controllato con node --check')
    print('OK - Logo, copertina, dati pratiche e altri file non modificati')
    print('NOTA - Riavvia/ricarica la PWA dopo la pubblicazione; controlla lo schema prima della firma.')
except (ValueError, OSError) as err:
    print(err)
    sys.exit(1)
