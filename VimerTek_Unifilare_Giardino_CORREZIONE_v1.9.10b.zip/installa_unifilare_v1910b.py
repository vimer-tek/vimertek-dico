#!/usr/bin/env python3
"""Aggiornamento sicuro SOLO di app.js, da v1.9.10a a v1.9.10b.
Nessuna modifica ai dati delle pratiche, copertina, logo o altri file.
"""
from pathlib import Path
from datetime import datetime
import subprocess
import sys
ROOT=Path.cwd()
APP=ROOT/'app.js'
PATCH=Path(__file__).resolve().parent/'unifilare_v1910b.js'
START='// VT_UNIFILARE_GERARCHICO_V1910A'
END='function refreshSchema(){'
try:
    if not APP.is_file(): raise ValueError('STOP: app.js non trovato; entra nella cartella del repository.')
    if not PATCH.is_file(): raise ValueError('STOP: unifilare_v1910b.js mancante; estrai lo ZIP completo.')
    before=APP.read_text(encoding='utf-8')
    if 'VT_UNIFILARE_GERARCHICO_V1910B' in before:
        print('OK: v1.9.10b già installata. Nessuna modifica.');sys.exit(0)
    if before.count(START)!=1 or before.count(END)!=1:
        raise ValueError('STOP: generatore v1.9.10a non trovato in forma attesa. Nessuna modifica.')
    start=before.index(START)
    end=before.index(END,start)
    old=before[start:end]
    required=['function vtSchemaHierarchicSupported()', "function unifilarSVG(onlyBoard='')", 'function unifilarPrintPages()', 'QPT-GEN']
    if not all(token in old for token in required):
        raise ValueError('STOP: codice v1.9.10a non corrispondente; nessuna modifica.')
    patch=PATCH.read_text(encoding='utf-8')
    if not all(token in patch for token in ['VT_UNIFILARE_GERARCHICO_V1910B','gardenTopology','function unifilarPrintPages()']):
        raise ValueError('STOP: patch incompleta, nessuna modifica.')
    after=before[:start]+patch+before[end:]
    # Check JS in a temporary file BEFORE touching the project.
    import tempfile
    with tempfile.TemporaryDirectory() as folder:
        test=Path(folder)/'app.js';test.write_text(after,encoding='utf-8')
        result=subprocess.run(['node','--check',str(test)],capture_output=True,text=True)
        if result.returncode:raise ValueError('STOP: sintassi JavaScript non valida. Nessuna modifica.\n'+result.stderr)
    backup=ROOT / f'app.js.backup_prima_unifilare_v1910b_{datetime.now():%Y%m%d_%H%M%S}'
    backup.write_text(before,encoding='utf-8')
    APP.write_text(after,encoding='utf-8')
    print('OK - Schema QPT/QPP/giardino v1.9.10b installato')
    print('OK - Backup:',backup.name)
    print('OK - node --check superato prima della modifica')
    print('OK - Non modificati logo, copertina e dati delle pratiche')
    print('ATTENZIONE - Schema ancora da verificare e validare tecnicamente prima della firma')
except (OSError,ValueError) as e:
    print(e);sys.exit(1)
