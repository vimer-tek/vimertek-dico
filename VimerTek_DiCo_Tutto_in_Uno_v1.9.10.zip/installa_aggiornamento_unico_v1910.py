#!/usr/bin/env python3
"""Vimer Tek Di.Co. 37/08 - pacchetto unico v1.9.10.
Installazione non distruttiva: aggiunge moduli JS, niente modifiche ad app.js.
Crea backup dei file HTML/package e verifica la build prima di confermare.
"""
from pathlib import Path
from datetime import datetime
import shutil, subprocess, sys, re, json

root = Path.cwd()
app, index, package, lock = (root / n for n in ('app.js','index.html','package.json','package-lock.json'))
mods = [
 ('vt-impianti-speciali-v198a.js', '<script src="vt-impianti-speciali-v198a.js"></script>'),
 ('vt-centro-operativo-v199.js', '<script src="vt-centro-operativo-v199.js"></script>'),
 ('firma-vimertek-solo-grafica.js', '<script type="module" src="./firma-vimertek-solo-grafica.js"></script>'),
 ('vt-completamento-v1910.js', '<script src="vt-completamento-v1910.js"></script>')
]
print('VIMER TEK Di.Co. 37/08 — aggiornamento unico v1.9.10')
for f in [app,index,package]+[root / f for f,_ in mods]:
    if not f.is_file(): sys.exit('ERRORE: manca '+f.name+'; nessun intervento effettuato.')
s=app.read_text('utf-8'); html=index.read_text('utf-8')
checks=['function render()','function save(','function printPart(','function attachmentWrite(', 'function attachmentRead(', 'function attachmentMeta()', 'function availablePrintSections()', 'function ministerialDico()', 'function printDocuments(', 'function fascicolo()']
missing=[x for x in checks if x not in s]
if missing: sys.exit('ERRORE: app.js non compatibile: '+', '.join(missing))
if not re.search(r'<script\s+src=[\'\"]app\.js[\'\"]\s*></script>',html,re.I) or '</body>' not in html:sys.exit('ERRORE: index.html inatteso; nessuna modifica.')
if re.search(r'<script\b[^>]*src=[\'\"](?:\./)?firma-vimertek\.js[\'\"]',html,re.I):sys.exit('Firma doppia già presente: interrompo per evitare conflitti.')
if html.lower().count('</body>') != 1:sys.exit('ERRORE: tag </body> duplicato.')
for fn,_ in mods:
    p=subprocess.run(['node','--check',str(root/fn)],text=True,capture_output=True)
    if p.returncode:sys.exit('ERRORE sintassi '+fn+'\n'+p.stderr)
if 'VT_COMPLETAMENTO_V1910' not in (root/mods[-1][0]).read_text('utf8'):sys.exit('Modulo di completamento incompleto.')
p=subprocess.run(['node','--check',str(app)],text=True,capture_output=True)
if p.returncode:sys.exit('ERRORE sintassi app.js\n'+p.stderr)
try: pkg=json.loads(package.read_text('utf-8'))
except Exception as e:sys.exit('ERRORE package.json: '+str(e))
backup=root/('backup_prima_v1910_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
backup.mkdir(); existed={f:f.exists() for f in [index,package,lock]}
for f in [index,package,lock,app]:
    if f.exists():shutil.copy2(f,backup/f.name)
print('BACKUP creato:',backup.name)
try:
    # vecchio modulo sostituito nella v1.9.8a
    html=re.sub(r'<script\s+src=[\'\"]vt-impianti-elettronici-v198\.js[\'\"]\s*></script>\s*','',html,flags=re.I)
    for fn,tag in mods:
        found=re.search(r'<script\b[^>]*src=[\'\"](?:\./)?'+re.escape(fn)+r'[\'\"][^>]*></script>',html,re.I)
        if found: print('Già collegato:',fn)
        else:
            html=html.replace('</body>','  '+tag+'\n</body>',1)
            print('Collegato:',fn)
    html,n=re.subn(r'(<small>Gestione documentazione impianti elettrici\s*[·-]\s*)v[0-9]+\.[0-9]+\.[0-9]+[a-z]?(</small>)',r'\g<1>v1.9.10\g<2>',html,count=1,flags=re.I)
    if n:print('Intestazione app aggiornata a v1.9.10')
    # pdf-lib è richiesta solo per la firma grafica, non per le altre funzioni
    declared='pdf-lib' in pkg.get('dependencies',{}) or 'pdf-lib' in pkg.get('devDependencies',{})
    if not declared or not (root/'node_modules/pdf-lib').is_dir():
        print('Installazione libreria firma grafica pdf-lib...')
        p=subprocess.run(['npm','install','pdf-lib','--save','--no-audit','--no-fund'],cwd=root)
        if p.returncode:raise RuntimeError('npm install pdf-lib non riuscito; controlla rete o package.json.')
    index.write_text(html,'utf-8')
    print('Compilazione di verifica...')
    p=subprocess.run(['npm','run','build'],cwd=root)
    if p.returncode:raise RuntimeError('npm run build non riuscito: modifica HTML annullata.')
    print('OK — v1.9.10 installata. app.js/logo/copertina/unifilare NON MODIFICATI.')
    print('COLLAUDA su pratica di prova: stampa ministeriale, check CEI, firma, backup locale. Google Drive richiede autorizzazione OAuth personale.')
except Exception as e:
    for f in [index,package,lock]:
        if existed[f]:shutil.copy2(backup/f.name,f)
        elif f.exists():f.unlink()
    sys.exit('ERRORE: '+str(e)+'\nFile modificati ripristinati da '+backup.name)
