#!/usr/bin/env python3
"""Vimer Tek Di.Co. 37/08: riquadro firma tecnico nello schema unifilare SVG.

Aggiorna esclusivamente la funzione unifilarSVG() in app.js. La firma resta
in bianco, compilabile a mano oppure apponibile al PDF con il modulo firma.
"""
from pathlib import Path
from datetime import datetime
import shutil
import subprocess
import sys

root = Path.cwd()
p = root / 'app.js'
marker = 'VT_UNIFILARE_FIRMA_DT_V197A'

print('Vimer Tek Di.Co. 37/08 - Riquadro firma nello schema unifilare')
if not p.is_file():
    sys.exit('ERRORE: app.js non trovato. Aprire il terminale nella cartella principale vimertek-dico.')
s = p.read_text(encoding='utf-8')
if marker in s:
    sys.exit('Riquadro firma gia presente nello schema unifilare. Nessuna modifica necessaria.')

start_marker = 'function unifilarSVG(){'
end_marker = 'function refreshSchema(){'
if s.count(start_marker) != 1 or s.count(end_marker) != 1:
    sys.exit('ERRORE: struttura unifilare non riconosciuta; nessuna modifica effettuata.')
a = s.index(start_marker)
b = s.index(end_marker, a)
segment = s[a:b]
height_anchor = ' const height=y+22;'
svg_footer_anchor = "${sections.join('')}${label(25,height-16,'VIMER TEK · Schema preliminare da verificare e validare tecnicamente',10,'start')}"
if segment.count(height_anchor) != 1 or segment.count(svg_footer_anchor) != 1:
    sys.exit('ERRORE: layout SVG differente dalla versione attesa; nessuna modifica effettuata. Invia una foto del terminale.')

# Aggiunta solo all'SVG: editor, anteprima e PDF utilizzano tutti unifilarSVG().
new_height = ''' // VT_UNIFILARE_FIRMA_DT_V197A: riquadro firma integrato nello schema SVG.
 const signatureY=y+12;
 const signatureW=480;
 const signatureX=width-signatureW-30;
 const signatureH=155;
 const height=signatureY+signatureH+34;
 const signedBy=state.technician||state.issuerTechnician||'Da compilare';
 const signatureBlock=`<rect x="${signatureX}" y="${signatureY}" width="${signatureW}" height="${signatureH}" fill="white" stroke="#24344c" stroke-width="1.5"/>${label(signatureX+18,signatureY+25,'FIRMA DEL DIRETTORE TECNICO',12,'start',true)}${label(signatureX+18,signatureY+49,`Nominativo: ${signedBy}`,11,'start')}${label(signatureX+18,signatureY+78,'Firma:',11,'start')}<path d="M${signatureX+82} ${signatureY+123} L${signatureX+signatureW-20} ${signatureY+123}" stroke="#24344c" stroke-width="1.2" fill="none"/>${label(signatureX+18,signatureY+145,'Data: ____/____/________',10,'start')}`;'''
new_footer = "${sections.join('')}${signatureBlock}${label(25,height-16,'VIMER TEK · Schema preliminare da verificare e validare tecnicamente',10,'start')}"
segment = segment.replace(height_anchor, new_height, 1).replace(svg_footer_anchor, new_footer, 1)
updated = s[:a] + segment + s[b:]

backup = root / ('app_backup_prima_firma_unifilare_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f') + '.js')
shutil.copy2(p, backup)
p.write_text(updated, encoding='utf-8')
try:
    checked = subprocess.run(['node', '--check', str(p)], cwd=root, text=True, capture_output=True)
    if checked.returncode != 0:
        raise RuntimeError(checked.stderr.strip())
    print('OK - Sintassi JavaScript corretta.')
    if (root / 'package.json').exists() and (root / 'node_modules').exists():
        built = subprocess.run(['npm', 'run', 'build'], cwd=root)
        if built.returncode != 0:
            raise RuntimeError('Compilazione non riuscita (npm run build).')
        print('OK - Compilazione PWA completata.')
except Exception as e:
    shutil.copy2(backup, p)
    sys.exit('ERRORE: ' + str(e) + '\nLa modifica e stata annullata. Backup: ' + backup.name)

print('OK - Riquadro FIRMA DEL DIRETTORE TECNICO inserito automaticamente in fondo allo schema unifilare.')
print('OK - Il nominativo e preso dal campo Responsabile tecnico della pratica.')
print('OK - Firma in bianco e data, con spazio per firma a mano o inserimento grafico nel PDF.')
print('OK - Il riquadro e visibile sia nell\'anteprima Unifilare sia nella stampa del fascicolo.')
print('NON modificati: index.html, style.css, logo, copertina, dati delle pratiche, controlli Di.Ri. o modulo CieSign.')
print('Backup salvato in:', backup.name)
print('Apri Unifilare e aggiorna la pagina con Ctrl+Shift+R per controllare il risultato.')
