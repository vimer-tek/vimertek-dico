#!/usr/bin/env python3
"""Vimer Tek Di.Co. v1.9.10c – correzione ragione sociale nel PDF.

Modifica SOLTANTO app.js (due riferimenti), crea backup e verifica sintassi
PRIMA di installare. Non tocca dati pratica, logo, copertina, altre sezioni.
"""
from pathlib import Path
from datetime import datetime
import subprocess
import tempfile
import sys

APP = Path.cwd() / 'app.js'
MARKER = '// VT_DICO_IMPRESA_INSTALLATRICE_V1910C'
OLD_SUMMARY = "entry('Soggetto dichiarante',state.issuerCompany||state.company)"
NEW_SUMMARY = "entry('Soggetto dichiarante',state.doc==='Di.Co.' && (state.declarationRole||'Impresa installatrice')==='Impresa installatrice' ? state.company : (state.issuerCompany||state.company))"
OLD_MINISTERIAL = '${e(state.issuerCompany||state.company)}'
NEW_MINISTERIAL = '${e(state.company)}'

def abort(msg):
    raise ValueError('STOP: ' + msg + ' Nessuna modifica eseguita.')

def main():
    if not APP.is_file():
        abort('app.js non trovato. Aprire Codespaces nella cartella principale del repository.')
    before = APP.read_text(encoding='utf-8')
    if MARKER in before:
        print('OK - Correzione v1.9.10c già installata: nessuna modifica.')
        return
    if before.count(OLD_SUMMARY) != 1:
        abort('scheda dati Di.Co./Di.Ri. non corrispondente alla versione verificata.')
    if before.count(OLD_MINISTERIAL) != 1 or before.count('function ministerialDico(){') != 1:
        abort('modello Di.Co. non corrispondente alla versione verificata.')
    if 'VT_UNIFILARE_GERARCHICO_V1910B' not in before:
        abort('attesa versione unifilare v1.9.10b, non trovata.')

    after = before.replace(OLD_SUMMARY, NEW_SUMMARY, 1)
    after = after.replace(OLD_MINISTERIAL, NEW_MINISTERIAL, 1)
    after = after.replace('function ministerialDico(){', MARKER + '\nfunction ministerialDico(){', 1)
    with tempfile.TemporaryDirectory() as tmp:
        test = Path(tmp)/'app.js'
        test.write_text(after,encoding='utf-8')
        result = subprocess.run(['node','--check',str(test)],capture_output=True,text=True)
        if result.returncode:
            abort('controllo JavaScript non superato. ' + result.stderr)

    backup = APP.with_name(f'app.js.backup_prima_dico_v1910c_{datetime.now():%Y%m%d_%H%M%S}')
    backup.write_text(before,encoding='utf-8')
    APP.write_text(after,encoding='utf-8')
    print('OK - Di.Co. v1.9.10c: ragione sociale da Impresa esecutrice')
    print('OK - Scheda dati: soggetto dichiarante impresa per Di.Co. installatrice')
    print('OK - Modello ministeriale (bozza): impresa corretta, firmatario separato')
    print('OK - Backup:',backup.name)
    print('OK - JavaScript verificato prima di modificare il file')
    print('OK - Nessun altro file, copertina, logo o dato delle pratiche modificato')
    print('AVVISO - Modello ancora BOZZA; verificare anagrafica, allegati e misure prima della firma.')

if __name__ == '__main__':
    try:
        main()
    except (OSError,ValueError) as ex:
        print(ex)
        sys.exit(1)
