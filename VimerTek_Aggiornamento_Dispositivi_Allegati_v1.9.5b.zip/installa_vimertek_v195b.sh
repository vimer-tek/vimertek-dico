#!/usr/bin/env bash
# Aggiornamento v1.9.5b (catalogo, allegati originali e semplice conferma eliminazione)
set -euo pipefail
if [ ! -f app.js ] || [ ! -f package.json ]; then
  echo 'ERRORE: apri il terminale nella cartella /workspaces/vimertek-dico' >&2
  exit 1
fi
if grep -q 'VT_ATTACHMENT_DB_V2' app.js; then
  echo '[1/4] Catalogo e allegati già aggiornati, mantengo il codice installato.'
else
  echo '[1/4] Installazione lettore PDF locale (Mozilla PDF.js)...'
  npm install --no-save --package-lock=false pdfjs-dist@4.10.38
  mkdir -p assets public/assets
  cp node_modules/pdfjs-dist/build/pdf.min.mjs assets/pdf.min.mjs
  cp node_modules/pdfjs-dist/build/pdf.worker.min.mjs assets/pdf.worker.min.mjs
  cp assets/pdf.min.mjs public/assets/pdf.min.mjs
  cp assets/pdf.worker.min.mjs public/assets/pdf.worker.min.mjs
  python3 patch_vimertek_dispositivi_allegati.py
fi
echo '[2/4] Conferma semplice di eliminazione pratica...'
python3 patch_conferma_eliminazione.py
echo '[3/4] Controllo sintassi JavaScript...'
node --check app.js
echo '[4/4] Compilazione applicazione...'
npm run build
echo 'Aggiornamento v1.9.5b completato. Premi Annulla/OK per eliminare una pratica, senza digitare il numero.'
