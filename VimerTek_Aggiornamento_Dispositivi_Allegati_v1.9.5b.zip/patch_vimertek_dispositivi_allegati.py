#!/usr/bin/env python3
"""Aggiornamento mirato per Vimer Tek Di.Co. 37/08: tipi dispositivo, allegati reali, stampa."""
from pathlib import Path
from datetime import datetime
import sys

p = Path('app.js')
if not p.is_file():
    sys.exit('ERRORE: avviare questo programma nella cartella che contiene app.js')
s = p.read_text(encoding='utf-8')
if 'VT_ATTACHMENT_DB_V2' in s:
    sys.exit('Aggiornamento già presente: nessuna modifica effettuata.')


def replace_once(old, new, label):
    global s
    n = s.count(old)
    if n != 1:
        sys.exit(f'ERRORE: {label}: atteso 1 punto, trovati {n}. Nessun file modificato.')
    s = s.replace(old, new, 1)

# Definisce le funzioni e il sistema di conservazione degli allegati (IndexedDB).
helpers = r'''// VT_ATTACHMENT_DB_V2: allegati veri conservati nel browser per questa pratica.
const VT_ATTACHMENT_DB='vt_dico_file_storage_v2';
function attachmentMeta(){if(!Array.isArray(state.attachmentFiles))state.attachmentFiles=[];return state.attachmentFiles}
function hasProjectData(){projectStore();return state.designers.length>0||state.projects.length>0}
function openAttachmentDB(){return new Promise((resolve,reject)=>{if(!('indexedDB' in window)){reject(new Error('IndexedDB non disponibile in questo browser.'));return}const r=indexedDB.open(VT_ATTACHMENT_DB,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('files'))r.result.createObjectStore('files',{keyPath:'id'})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error||new Error('Impossibile aprire archivio allegati'))})}
async function attachmentWrite(entry){const db=await openAttachmentDB();try{await new Promise((resolve,reject)=>{const tx=db.transaction('files','readwrite');tx.objectStore('files').put(entry);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)})}finally{db.close()}}
async function attachmentRead(id){const db=await openAttachmentDB();try{return await new Promise((resolve,reject)=>{const r=db.transaction('files','readonly').objectStore('files').get(id);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}finally{db.close()}}
async function attachmentDelete(id){const db=await openAttachmentDB();try{await new Promise((resolve,reject)=>{const tx=db.transaction('files','readwrite');tx.objectStore('files').delete(id);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)})}finally{db.close()}}
function imageAsDataURL(blob){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(reader.error||new Error('Errore lettura immagine'));reader.readAsDataURL(blob)})}
let vtPdfLoader=null;
function loadVtPdfJs(){if(!vtPdfLoader)vtPdfLoader=import(new URL('assets/pdf.min.mjs',document.baseURI).href).then(pdf=>{pdf.GlobalWorkerOptions.workerSrc=new URL('assets/pdf.worker.min.mjs',document.baseURI).href;return pdf});return vtPdfLoader}
async function buildRealAttachmentPages(){let output='';let totalPages=0;for(const meta of attachmentMeta()){
 const stored=await attachmentRead(meta.id);if(!stored||!stored.file)throw new Error('Allegato non trovato nel browser: '+meta.name+'. Ricarica il file dalla sezione Allegati.');
 const f=stored.file;const type=(f.type||'').toLowerCase(),isPDF=type==='application/pdf'||/\.pdf$/i.test(meta.name);let images=[];
 if(isPDF){let pdfjs;try{pdfjs=await loadVtPdfJs()}catch(e){throw new Error('Lettore PDF non disponibile. Verifica che i due file pdf.min.mjs e pdf.worker.min.mjs siano nella cartella assets.')}let doc;try{doc=await pdfjs.getDocument({data:new Uint8Array(await f.arrayBuffer())}).promise}catch(e){throw new Error('Impossibile leggere il PDF '+meta.name+': '+(e.message||e))}if(doc.numPages>80)throw new Error('Il PDF '+meta.name+' supera 80 pagine: dividilo in file più piccoli.');for(let n=1;n<=doc.numPages;n++){const page=await doc.getPage(n),unit=page.getViewport({scale:1}),vp=page.getViewport({scale:Math.min(2.7,1450/unit.width)}),canvas=document.createElement('canvas');canvas.width=Math.round(vp.width);canvas.height=Math.round(vp.height);await page.render({canvasContext:canvas.getContext('2d',{alpha:false}),viewport:vp}).promise;images.push(canvas.toDataURL('image/jpeg',.92));canvas.width=canvas.height=1;}await doc.destroy();}
 else if(/^image\/(png|jpeg|webp|gif|bmp)$/.test(type)||/\.(png|jpg|jpeg|webp)$/i.test(meta.name)){images.push(await imageAsDataURL(f));}
 else throw new Error('Formato non stampabile: '+meta.name+'. Carica PDF, JPG o PNG.');
 for(let i=0;i<images.length;i++){totalPages++;if(totalPages>100)throw new Error('Troppi fogli allegati (oltre 100). Dividi il fascicolo.');output+=`<section class="print-section vt-attachment-page"><div class="vt-attachment-title">ALLEGATO · ${esc(meta.name)}${images.length>1?' · pag. '+(i+1)+'/'+images.length:''}</div><img alt="Pagina allegato" src="${images[i]}"></section>`;}
 }return output}
async function removeStoredAttachment(i){const meta=attachmentMeta()[i];if(!meta)return;if(!confirm('Rimuovere l’allegato '+meta.name+' dalla pratica?'))return;try{await attachmentDelete(meta.id)}catch(err){alert('Impossibile cancellare il file: '+err.message);return}attachmentMeta().splice(i,1);if(!attachmentMeta().some(x=>x.name===meta.name))state.attachments=(state.attachments||[]).filter(x=>x!==meta.name);save(false);render()}
'''
replace_once('function attachments(){', helpers + 'function attachments(){', 'inserimento supporto allegati')

# Sostituisce sola UI allegati, lascia invariato resto dell'app.
a = s.index('function attachments(){'); b = s.index('function schemaItems(){', a)
s = s[:a]+'''function attachments(){const meta=attachmentMeta(),savedNames=new Set(meta.map(x=>x.name)),legacy=(state.attachments||[]).map((name,i)=>({name,i})).filter(x=>!savedNames.has(x.name));return `<div class=card><h2>Allegati originali</h2><p class=muted>Carica PDF e immagini (JPG, PNG, WebP). Questa versione conserva il file completo in IndexedDB nel browser attuale: verrà inserito nel fascicolo stampato. Non basta avere registrato il nome.</p><input id=files type=file multiple accept=".pdf,.png,.jpg,.jpeg,.webp,application/pdf,image/png,image/jpeg,image/webp"><button onclick='addFiles()'>+ Conserva file allegati</button><h3>Documenti pronti da stampare</h3>${meta.length?meta.map((x,i)=>`<div class="archive-item"><div><b>${esc(x.name)}</b><br><small>${Math.ceil((x.size||0)/1024)} KB · originale conservato nel browser</small></div><button class='danger' onclick='removeStoredAttachment(${i})'>Rimuovi</button></div>`).join(''):'<p class=muted>Nessun file originale conservato.</p>'}${legacy.length?`<h3>Vecchi allegati da ricaricare</h3><p class=muted>Di questi documenti l’app aveva registrato soltanto il nome. Se vuoi stamparli devi caricarli nuovamente qui.</p>${legacy.map(x=>`<div class="archive-item"><span>${esc(x.name)} · solo nome</span><button onclick='delFile(${x.i})'>×</button></div>`).join('')}`:''}<p class=muted>Per un altro dispositivo o dopo una pulizia del browser, conserva una copia originale di ogni documento: i file non sono ancora sincronizzati online.</p></div>`}
''' + s[b:]

# Catalogo tipi dispositivi + simboli schematici non normativi.
start=s.index('function schemaDevice(x,y,type){')
end=s.index('function unifilarSVG(){',start)
catalog=r'''const SCHEMA_DEVICE_CATALOG=[
 ['Protezione',['MT','Magnetotermico'],['MTD','Magnetotermico differenziale'],['ID','Differenziale puro'],['MCCB','Interruttore scatolato'],['ACB','Interruttore aperto'],['MOT','Salvamotore'],['RTH','Relè termico']],
 ['Sezionamento e fusibili',['SEZ','Sezionatore'],['IMS','Interruttore manovra-sezionatore'],['PF','Portafusibili'],['FUS','Fusibile'],['SF','Sezionatore con fusibili'],['COMM','Commutatore'],['ATS','Commutatore automatico ATS']],
 ['Sovratensioni',['SPD1','SPD Tipo 1'],['SPD2','SPD Tipo 2'],['SPD12','SPD Tipo 1+2'],['SPD3','SPD Tipo 3']],
 ['Comando e automazione',['KM','Contattore'],['KA','Relè ausiliario'],['KP','Relè passo-passo'],['KT','Temporizzatore'],['AST','Orologio astronomico'],['CREP','Interruttore crepuscolare'],['DIM','Dimmer'],['ACT','Attuatore domotico'],['PLC','PLC']],
 ['Controllo e misura',['EM','Contatore energia'],['ANL','Analizzatore di rete'],['VM','Voltmetro'],['AM','Amperometro'],['RV','Relè controllo tensione'],['RF','Relè controllo fasi'],['RDT','Relè differenziale con toroide']],
 ['Alimentazione',['TRAFO','Trasformatore'],['PSU','Alimentatore AC/DC'],['UPS','Gruppo di continuità UPS'],['INV','Inverter']],
 ['Fotovoltaico / DC',['MTDC','Magnetotermico DC'],['SDC','Sezionatore DC'],['FDC','Fusibile DC'],['SPDDC','SPD lato DC']],
 ['Comandi e altri',['SG','Bobina di sgancio'],['LED','Spia luminosa'],['PB','Pulsante'],['ALTRO','Dispositivo personalizzato']]
];
function schemaDeviceSelect(i,value){const known=SCHEMA_DEVICE_CATALOG.some(g=>g.slice(1).some(x=>x[0]===value));return `<select onchange='schemaEdit(${i},"device",this.value)'>${!known?`<option value="${escAttr(value)}" selected>${esc(value)} (precedente)</option>`:''}${SCHEMA_DEVICE_CATALOG.map(g=>`<optgroup label="${escAttr(g[0])}">${g.slice(1).map(([id,name])=>`<option value="${escAttr(id)}" ${value===id?'selected':''}>${esc(name)}</option>`).join('')}</optgroup>`).join('')}</select>`}
function schemaDevice(x,y,type){let t=String(type||'MT').toUpperCase(),line=`<path d="M${x-12} ${y+34}L${x+12} ${y+10}" stroke="#24344c" stroke-width="1.7"/>`,symbol=line;
 if(t==='ID'||t==='MTD')symbol+=`<ellipse cx="${x}" cy="${y+22}" rx="9" ry="12" fill="none" stroke="#24344c" stroke-width="1.2"/>`;
 else if(/^SPD/.test(t))symbol=`<path d="M${x+4} ${y+8}l-13 18h12l-7 13 19-22h-12z" fill="none" stroke="#24344c" stroke-width="1.7"/>`;
 else if(['FUS','FDC','PF','SF'].includes(t))symbol=`<rect x="${x-7}" y="${y+11}" width="14" height="23" fill="none" stroke="#24344c" stroke-width="1.7"/><path d="M${x} ${y+6}v5m0 23v5" stroke="#24344c"/>`;
 else if(['KM','KA','KP','KT','RTH','RDT'].includes(t))symbol=`<circle cx="${x}" cy="${y+22}" r="12" fill="none" stroke="#24344c" stroke-width="1.7"/>`;
 else if(['EM','ANL','VM','AM'].includes(t))symbol=`<circle cx="${x}" cy="${y+22}" r="15" fill="none" stroke="#24344c" stroke-width="1.7"/><text x="${x}" y="${y+26}" text-anchor="middle" font-size="9">${['VM','AM'].includes(t)?t[0]:'M'}</text>`;
 else if(['TRAFO','PSU','UPS','INV'].includes(t))symbol=`<circle cx="${x-7}" cy="${y+22}" r="9" fill="none" stroke="#24344c"/><circle cx="${x+7}" cy="${y+22}" r="9" fill="none" stroke="#24344c"/>`;
 return `<rect x="${x-21}" y="${y}" width="42" height="45" fill="white" stroke="#24344c" stroke-width="1.7"/>${symbol}<text x="${x}" y="${y-7}" text-anchor="middle" font-size="${t.length>5?8:10}" fill="#25344a">${esc(t)}</text>`}
'''
s=s[:start]+catalog+s[end:]
replace_once("${schemaSelect(c.device||'MT',[['MT','Magnetotermico'],['MTD','Magnetotermico differenziale'],['ID','Differenziale'],['ALTRO','Altro']],`schemaEdit(${i},\"device\",this.value)`)}", "${schemaDeviceSelect(i,c.device||'MT')}", 'catalogo dispositivi nel menu')

# Conserviamo la correzione ai dropdown già applicata dall'utente, se serve.
s=s.replace('function schemaSelect(value,options,fn){return `<select onchange="${fn}"','function schemaSelect(value,options,fn){return `<select onchange=\'${fn}\'')

# Aggiorna stampa: sezione progettisti solo con dati, allegati solo originali.
start=s.index('const PRINT_SECTIONS='); end=s.index('function isNotApplicable',start)
s=s[:start]+'''const PRINT_SECTIONS=[['cover','Copertina e indice (pagina 2)'],['declaration','Dichiarazione / scheda dati'],['ministerial','Di.Co. · modello ministeriale (bozza)'],['materials','Relazione materiali'],['circuits','Quadri e circuiti'],['unifilar','Schema unifilare'],['verification','Rapporto verifiche'],['projects','Progettisti e progetti'],['attachments','Allegati originali (file PDF e immagini)']];
function availablePrintSections(){return PRINT_SECTIONS.filter(([id])=>id!=='projects'||hasProjectData()).filter(([id])=>id!=='attachments'||attachmentMeta().length>0)}
function fascicolo(){return `<div class='card'><h2>Stampa fascicolo tecnico</h2><p class='muted'>Stampa A4 del fascicolo o dei singoli documenti. Le sezioni vuote non vengono stampate. Gli allegati originali (PDF e immagini) sono aggiunti come pagine, non come elenco di nomi.</p><div class='actions'><button type='button' onclick='printFascicolo()'>Stampa fascicolo completo</button><button type='button' class='secondary' onclick='printSelected()'>Stampa documenti selezionati</button></div><h3>Documenti da stampare</h3><div class='print-options'>${availablePrintSections().map(([id,title])=>`<label class='print-option'><input type='checkbox' data-print-section='${id}' ${id==='cover'?'':'checked'}> ${esc(title)}</label>`).join('')}</div>${!attachmentMeta().length?'<p class=muted>Non ci sono allegati originali da stampare: carica PDF o immagini nella sezione Allegati. I vecchi nomi da soli non bastano.</p>':''}<p class='muted'>La dichiarazione ministeriale resta una bozza operativa da verificare. La copertina definitiva non è stata modificata.</p></div><div class='card'><h3>Anteprima copertina</h3><div class='cover'><img src='assets/logo-vimertek.png' alt='Vimer Tek'><h2>FASCICOLO TECNICO IMPIANTO ELETTRICO</h2><h3>${esc(state.doc)}</h3><div>${esc(state.practiceNo)}</div><div class='box'><b>Cliente:</b> ${esc(state.client||'Da compilare')}<br><b>Ubicazione:</b> ${esc([state.address,state.city,state.province].filter(Boolean).join(', ')||'Da compilare')}<br><b>Intervento:</b> ${esc(state.work)}<br><b>Impresa:</b> ${esc(state.company||'Da compilare')}<br><b>Responsabile tecnico:</b> ${esc(state.technician||'Da compilare')}</div></div></div>`}
function printFascicolo(){printDocuments(availablePrintSections().map(x=>x[0]))}
function printSelected(){const ids=[...document.querySelectorAll('[data-print-section]:checked')].map(x=>x.dataset.printSection);if(!ids.length){alert('Seleziona almeno un documento.');return}printDocuments(ids)}
''' + s[end:]

# Evita che lo SVG dell’unifilare provochi una pagina bianca prima del disegno.
replace_once('unifilarSVG().replace(/width="\\d+" height="420" role=/,\'width="100%" height="auto" role=\')', 'unifilarSVG().replace(/width="\\d+" height="\\d+" role=/,\'width="100%" height="auto" role=\')', 'dimensioni SVG nello stampato')

# Sicurezza ulteriore: anche se un'opzione vecchia richiama la sezione, niente pagine vuote.
s=s.replace("if(id==='projects'){projectStore();return", "if(id==='projects'){projectStore();if(!hasProjectData())return '';return",1)
a=s.index("if(id==='attachments')return `<section class='print-section'>")
b=s.index(";return ''}",a)
s=s[:a]+"if(id==='attachments')return ''"+s[b:]

# Converte la stampa in asincrona (per leggere i veri allegati) prima di aprire la finestra.
replace_once("function printDocuments(ids){save(false);printIds=ids;", "async function printDocuments(ids){save(false);printIds=ids.filter(id=>id!=='projects'||hasProjectData()).filter(id=>id!=='attachments'||attachmentMeta().length>0);", 'funzione stampa')
replace_once("<title>${esc(state.practiceNo)} - ${ids.length===PRINT_SECTIONS.length?'Fascicolo':'Documenti'}</title>", "<title>${esc(state.practiceNo)} - Documenti</title>", 'titolo stampa')
replace_once("</style></head><body>${ids.map(printPart).join('')}</body></html>`;", """/* Allegati originali: ciascuna pagina è stampata per intero, senza elenco file. */
.vt-attachment-page{break-before:page;page-break-before:always;break-inside:avoid;page-break-inside:avoid;padding:0!important;margin:0;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;min-height:0}
.vt-attachment-title{width:100%;font:9pt Arial,sans-serif;color:#596571;border-bottom:1px solid #aab2bc;margin:0 0 3mm;padding-bottom:2mm;overflow-wrap:anywhere}
.vt-attachment-page img{max-width:100%;width:auto;height:auto;max-height:222mm;object-fit:contain;display:block;margin:0 auto}
@media print{.vt-attachment-page{page:auto;break-before:page!important;break-after:page!important}.vt-attachment-page img{max-height:222mm}}
</style></head><body>${printIds.map(id=>id==='attachments'?realAttachmentHTML:printPart(id)).join('')}</body></html>`;""", 'sostituzione elenco allegati e stile')
old="const html=`<!doctype html><html lang='it'>"
replace_once(old, '''const w=window.open('','_blank');if(!w){alert('Il browser ha bloccato la finestra di stampa. Consenti i popup.');return}w.document.open();w.document.write('<!doctype html><html><head><meta charset="utf-8"></head><body style="font:16px Arial;padding:30px">Preparazione dei documenti originali per la stampa...</body></html>');w.document.close();
let realAttachmentHTML='';try{if(printIds.includes('attachments'))realAttachmentHTML=await buildRealAttachmentPages()}catch(err){w.document.body.textContent='Impossibile preparare gli allegati: '+err.message;alert('Stampa annullata: '+err.message);return}
const html=`<!doctype html><html lang='it'>''', 'stampa allegati asincrona')
replace_once("const w=window.open('','_blank');if(!w){alert('Il browser ha bloccato la finestra di stampa. Consenti i popup per questa applicazione.');return}w.document.open();w.document.write(html);w.document.close();w.focus();w.addEventListener('load',()=>{setTimeout(()=>w.print(),350)},{once:true});}", """w.document.open();w.document.write(html);w.document.close();w.focus();await Promise.all([...w.document.images].map(img=>img.complete?Promise.resolve():new Promise(resolve=>{img.onload=resolve;img.onerror=resolve;setTimeout(resolve,5000)})));setTimeout(()=>w.print(),450);}""", 'attesa immagini')

# La gestione dei file conserva contenuti reali e metadati separati.
start=s.index('function addFiles(){');end=s.index('function esc(s=',start)
s=s[:start]+r'''async function addFiles(){const input=document.getElementById('files');const selected=[...(input?.files||[])];if(!selected.length){alert('Seleziona almeno un PDF o immagine.');return}const meta=attachmentMeta();let added=0;for(const f of selected){if(!(/\.pdf$|\.(png|jpe?g|webp)$/i.test(f.name))){alert('Formato non supportato: '+f.name+'. Usa PDF, JPG, PNG o WebP.');continue}if(meta.some(x=>x.name===f.name)){alert('Già presente: '+f.name+'. Rimuovi prima la versione precedente per sostituirla.');continue}const id=state.practiceNo+'::'+(window.crypto?.randomUUID?.()||Date.now()+'_'+added);try{await attachmentWrite({id,file:f})}catch(err){alert('Errore di archiviazione di '+f.name+': '+err.message);break}meta.push({id,name:f.name,size:f.size,type:f.type||''});state.attachments=state.attachments||[];if(!state.attachments.includes(f.name))state.attachments.push(f.name);added++}if(added){save(false);render();alert(added+' file originali conservati nel browser. Ora potranno essere stampati nel fascicolo.')}}
function delFile(i){state.attachments.splice(i,1);save(false);render()}
''' +s[end:]

# Backup atomico a nome non conflittuale, poi scrittura (nessun altro file toccato).
backup=Path('app_backup_prima_patch_dispositivi_allegati.js')
if backup.exists():
    backup=Path('app_backup_prima_patch_dispositivi_allegati_'+datetime.now().strftime('%Y%m%d%H%M%S')+'.js')
backup.write_text(p.read_text(encoding='utf-8'),encoding='utf-8')
p.write_text(s,encoding='utf-8')
print('Aggiornamento completato. Copia di sicurezza:',backup)
print('Sono stati modificati soltanto i contenuti del file app.js')
print('IMPORTANTE: per i PDF servono assets/pdf.min.mjs e assets/pdf.worker.min.mjs (PDF.js 4.10.38).')
