#!/usr/bin/env python3
"""Usa una sola conferma per cancellare una pratica, pulendo anche i file originali."""
from pathlib import Path
from datetime import datetime
import sys

p=Path('app.js')
if not p.is_file():
    sys.exit('ERRORE: esegui il comando nella cartella principale del progetto (app.js non trovato).')
s=p.read_text(encoding='utf-8')
marker='VT_DELETE_CONFIRM_SIMPLE_V1'
if marker in s:
    print('Conferma eliminazione semplice già installata: nessun cambiamento.')
    sys.exit(0)
start=s.find('function deletePractice(no){')
end=s.find('function openPractice(no){',start)
if start<0 or end<0:
    sys.exit('ERRORE: funzione elimina pratica non trovata. Nessun file modificato.')
new='''// VT_DELETE_CONFIRM_SIMPLE_V1: conferma sì/no, senza digitare il numero della pratica.
async function deletePractice(no){
 const a=archive(),p=a.find(x=>x.practiceNo===no);
 if(!p)return;
 if(!confirm('Sei sicuro di voler eliminare definitivamente la pratica '+no+'?\\nCliente: '+(p.client||'Non indicato')+'\\n\\nQuesta operazione non può essere annullata.'))return;
 // Elimina anche gli eventuali allegati originali salvati nel browser per la pratica.
 const storedFiles=Array.isArray(p.attachmentFiles)?p.attachmentFiles:[];
 if(storedFiles.length){
  if(typeof attachmentDelete!=='function'){
   alert('Impossibile eliminare gli allegati originali. Pratica non cancellata.');return;
  }
  try{for(const file of storedFiles)await attachmentDelete(file.id)}
  catch(err){alert('Errore nella cancellazione degli allegati. Pratica non cancellata: '+(err.message||err));return;}
 }
 const updated=a.filter(x=>x.practiceNo!==no);
 localStorage.setItem('vt_dico_archive',JSON.stringify(updated));
 if(state.practiceNo===no){state=emptyState();localStorage.setItem('vt_dico',JSON.stringify(state));}
 active=0;render();alert('Pratica '+no+' eliminata da questo dispositivo.');
}
'''
backup=Path('app_backup_prima_conferma_eliminazione.js')
if backup.exists():
    backup=Path('app_backup_prima_conferma_eliminazione_'+datetime.now().strftime('%Y%m%d%H%M%S')+'.js')
backup.write_text(s,encoding='utf-8')
p.write_text(s[:start]+new+s[end:],encoding='utf-8')
print('Conferma eliminazione semplice installata! Backup:',backup)
