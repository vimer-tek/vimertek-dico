from pathlib import Path
from shutil import copy2
import re

config=Path('vite.config.ts')
if not config.is_file():
    raise SystemExit('STOP: vite.config.ts non trovato. Nessuna modifica eseguita.')
s=config.read_text(encoding='utf-8')
if 'icons:[{' in s or re.search(r'icons\s*:\s*\[\s*\{',s):
    raise SystemExit('STOP: il manifest ha gia icone. Controlla manualmente prima di procedere.')
pattern=r'icons\s*:\s*\[\s*\]'
if len(re.findall(pattern,s))!=1:
    raise SystemExit('STOP: non trovo una sola voce icons:[] in vite.config.ts. Nessuna modifica eseguita.')
files=['icon-192.png','icon-512.png','icon-maskable-512.png','apple-touch-icon.png','favicon-48.png']
for name in files:
    origin=Path('icone')/name
    if not origin.is_file():
        raise SystemExit(f'STOP: manca {origin}. Nessuna modifica eseguita.')
backup=Path('vite.config.ts.backup_prima_icona_vimertek')
if not backup.exists():
    copy2(config,backup)
dest=Path('public/icons')
dest.mkdir(parents=True,exist_ok=True)
for name in files:
    copy2(Path('icone')/name,dest/name)
icons="icons:[{src:'/vimertek-dico/icons/icon-192.png',sizes:'192x192',type:'image/png',purpose:'any'},{src:'/vimertek-dico/icons/icon-512.png',sizes:'512x512',type:'image/png',purpose:'any'},{src:'/vimertek-dico/icons/icon-maskable-512.png',sizes:'512x512',type:'image/png',purpose:'maskable'}]"
config.write_text(re.sub(pattern,lambda _:icons,s,count=1),encoding='utf-8')
print('OK - Icone Vimer Tek installate nella PWA')
print('OK - Configurazione VitePWA aggiornata; copertina e logo originale non modificati')
print('Backup salvato:',backup)
