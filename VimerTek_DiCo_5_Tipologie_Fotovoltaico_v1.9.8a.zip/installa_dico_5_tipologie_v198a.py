#!/usr/bin/env python3
"""Vimer Tek Di.Co. 37/08 - 5 tipologie (4 elettroniche + fotovoltaico).
Non modifica app.js, copertina, logo, schema unifilare esistente o pratiche.
Il modulo e' collegato al termine dello script app.js; sostituisce l'eventuale
collegamento del precedente modulo v1.9.8 per evitare duplicazioni.
"""
from pathlib import Path
from datetime import datetime
import re, shutil, subprocess, sys

root = Path.cwd()
index = root/'index.html'
app = root/'app.js'
module = root/'vt-impianti-speciali-v198a.js'
files = [index,app,module]
print('VIMER TEK - Di.Co. antennistica, videosorveglianza, antifurto, LAN e FOTOVOLTAICO v1.9.8a')
for p in files:
    if not p.is_file(): sys.exit('ERRORE - File mancante: '+p.name+'. Nessuna modifica effettuata.')
old = index.read_text(encoding='utf-8')
source = app.read_text(encoding='utf-8')
js = module.read_text(encoding='utf-8')
checks = ('function pratica()', 'function impianto()', 'function materials()',
          'function circuits()', 'function level()', 'function checks()',
          'function unifilar()', 'function fascicolo()', 'function printFascicolo()',
          'function printPart(id)', 'function ministerialDico()',
          'function availablePrintSections()', 'function printDocuments(', 'function render()')
missing=[x for x in checks if x not in source]
if missing:
    sys.exit('ERRORE - app.js non riconosciuto: '+', '.join(missing)+'. Nessuna modifica effettuata.')
if 'VT_DICO_IMPIANTI_V198A' not in js or "'Fotovoltaico'" not in js:
    sys.exit('ERRORE - Modulo incompleto. Nessuna modifica effettuata.')
for path in (app,module):
    r=subprocess.run(['node','--check',str(path)],capture_output=True,text=True)
    if r.returncode:
        sys.exit('ERRORE - Sintassi JS '+path.name+': '+r.stderr)
newtag='<script src="vt-impianti-speciali-v198a.js"></script>'
if newtag in old:
    print('AGGIORNAMENTO GIA INSTALLATO - index.html contiene il modulo v1.9.8a.')
    sys.exit(0)
# Only accept known script tags, not other unknown patches.
oldtag=re.compile(r'<script\s+src=[\'\"]vt-impianti-elettronici-v198\.js[\'\"]\s*></script>\s*',re.I)
appscript=re.compile(r'<script\s+src=[\'\"]app\.js[\'\"]\s*></script>',re.I)
if len(appscript.findall(old))!=1:
    sys.exit('ERRORE - Collegamento di app.js non trovato una volta sola in index.html. Nessuna modifica.')
if len(oldtag.findall(old))>1:
    sys.exit('ERRORE - Doppio modulo precedente in index.html; nessuna modifica.')
new=oldtag.sub('',old)
new=appscript.sub(lambda m:m.group(0)+'\n'+newtag,new,count=1)
backup=root/('backup_prima_5_tipologie_v198a_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
backup.mkdir()
shutil.copy2(index,backup/'index.html')
shutil.copy2(app,backup/'app.js')
print('OK - Backup:',backup.name)
try:
    index.write_text(new,encoding='utf-8')
    if (root/'package.json').exists() and (root/'node_modules').exists():
        r=subprocess.run(['npm','run','build'],cwd=root)
        if r.returncode: raise RuntimeError('npm run build non riuscito')
    print('OK - 5 modalita: Antennistica TV/SAT, Videosorveglianza, Antifurto, Reti LAN, Fotovoltaico.')
    print('OK - FV: moduli, stringhe, inverter, accumulo, quadri/protezioni AC/DC, verifiche e relazione PDF.')
    print('OK - Classificazione FV lettera A; impianti elettronici lettera B (ove applicabile).')
    print('NON modificati: app.js, copertina originale, logo, schema elettrico esistente, controlli Di.Ri.')
    print('AVVISO - Da collaudare in Vite prima di salvare su GitHub.')
except Exception as exc:
    shutil.copy2(backup/'index.html',index)
    sys.exit('ERRORE - '+str(exc)+'; index.html ripristinato. Non fare git push.')
